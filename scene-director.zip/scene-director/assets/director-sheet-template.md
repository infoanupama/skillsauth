# Director Sheet — Fillable Template

Copy this block, fill in the fields, hand to Scene Director (or pipe to `scripts/render_prompt.py`).

```yaml
logline: "One sentence — what is this image?"

subject:
  description: "Who or what, visually specific"
  count: 1
  identity_note: null

action: "Present-tense verb in a specific beat"

environment:
  location: "Where"
  signifiers:
    - "Detail 1 that tells us where/when"
    - "Detail 2"
    - "Detail 3 (max 3)"

time:
  clock: "e.g. golden hour, 2am, noon"
  era: "e.g. present day, 1970s"

shot:
  type: "wide | medium | medium_close | close_up | extreme_close_up | over_the_shoulder | pov"
  angle: "eye_level | low | high | dutch | overhead"
  height: "eye-level | chest-height | hip | ground"

camera:
  format: "35mm_film | medium_format | digital_full_frame | smartphone | super8"
  lens_mm: 35
  aperture: "f/2.0"
  depth_of_field: "shallow | medium | deep"

lighting:
  key: "source + direction + quality"
  fill: "source + quality (or null)"
  rim: null
  practicals:
    - "in-scene source 1 (lamp, phone, neon...)"
  overall_quality: "soft | hard | mixed"
  temperature_k: 3200

composition:
  rule: "thirds | center | symmetry | leading_lines | negative_space"
  subject_position: "left_third | center | right_third | golden_ratio"
  negative_space_for: "title top-left | null"

color:
  palette:
    - "warm tones"
  grade: "Kodak Portra 400 | teal and orange | bleach bypass | ..."
  contrast: "low | medium | high"
  saturation: "muted | natural | vibrant"

mood:
  - "specific word 1"
  - "specific word 2"

deliverable:
  aspect_ratio: "3:2 | 16:9 | 9:16 | 1:1 | 4:5"
  orientation: "landscape | portrait | square"
  use_case: "what's this for?"

anti_list:
  - "plastic skin"
  - "stock-photo smile"
  - "generic corporate office"
  - "over-sharp digital look"

target_model: "gpt-image-2 | openart | midjourney | flux | nano-banana"

notes: null
```

## Minimum viable sheet

If you're in a hurry, fill only these and let defaults handle the rest:

```yaml
logline: ""
subject: { description: "" }
action: ""
environment: { location: "", signifiers: [""] }
shot: { type: "" }
lighting: { key: "" }
color: { grade: "" }
mood: [""]
deliverable: { aspect_ratio: "" }
anti_list: [""]
target_model: ""
```

Everything else defaults from `references/director-sheet-schema.md`.
