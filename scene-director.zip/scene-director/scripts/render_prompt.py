#!/usr/bin/env python3
"""
render_prompt.py — compile a director-sheet JSON into a model-specific image prompt.

Usage:
    python render_prompt.py sheet.json
    python render_prompt.py sheet.json --model midjourney
    cat sheet.json | python render_prompt.py -

The director sheet schema lives in references/director-sheet-schema.md.
The compile rules for each model live in references/gpt-image-2-prompting.md
(and sibling files for other models).

This script is intentionally small and dependency-free — it's a reference
implementation of the compile step in the scene-director skill. Production
integrations (OpenArt, Claude skills runtime, etc.) should reuse the
template strings below rather than the argument parsing glue.
"""
from __future__ import annotations

import argparse
import json
import sys
from typing import Any

DEFAULTS: dict[str, Any] = {
    "camera": {"lens_mm": 35, "format": "35mm_film", "aperture": "f/2.8", "depth_of_field": "medium"},
    "shot": {"angle": "eye_level"},
    "lighting": {"overall_quality": "soft"},
    "composition": {"rule": "thirds", "subject_position": "left_third", "negative_space_for": None},
    "color": {"grade": "Kodak Portra 400", "contrast": "medium", "saturation": "natural"},
    "anti_list": ["plastic skin", "stock-photo smile", "over-sharp digital look"],
}

# Map schema shot-type keys to natural-language phrases.
SHOT_PHRASE = {
    "extreme_wide": "An extreme wide shot",
    "wide": "A wide shot",
    "medium_wide": "A medium-wide shot",
    "medium": "A medium shot",
    "medium_close": "A medium close-up",
    "close_up": "A close-up",
    "extreme_close_up": "An extreme close-up",
    "over_the_shoulder": "An over-the-shoulder shot",
    "pov": "A point-of-view shot",
}

ASPECT_TO_SIZE = {
    "1:1": "1024x1024",
    "16:9": "1792x1024",
    "9:16": "1024x1792",
    "3:2": "1536x1024",
    "2:3": "1024x1536",
    "4:5": "1024x1280",
}


def merge_defaults(sheet: dict) -> dict:
    """Shallow-merge defaults into empty/missing fields without overwriting user values."""
    out = json.loads(json.dumps(sheet))  # deep copy
    for key, defaults in DEFAULTS.items():
        if key not in out or out[key] is None:
            out[key] = defaults
        elif isinstance(defaults, dict):
            for subkey, subval in defaults.items():
                out[key].setdefault(subkey, subval)
        elif isinstance(defaults, list) and not out.get(key):
            out[key] = defaults
    return out


def _opt(value: Any, prefix: str = "", suffix: str = "") -> str:
    """Render value with prefix/suffix only if value is truthy."""
    if not value:
        return ""
    return f"{prefix}{value}{suffix}"


def compile_gpt_image_2(sheet: dict) -> str:
    s = merge_defaults(sheet)

    shot_phrase = SHOT_PHRASE.get(s["shot"]["type"], "A shot")
    subject = s["subject"]["description"]
    action = s["action"].rstrip(".")
    env = s["environment"]
    signifiers = ", ".join(env.get("signifiers", []))
    time_clock = s.get("time", {}).get("clock", "")
    time_era = s.get("time", {}).get("era", "")

    cam = s["camera"]
    lighting = s["lighting"]
    practicals = "; ".join(lighting.get("practicals", []) or [])
    color = s["color"]
    comp = s["composition"]
    mood = ", ".join(s.get("mood", []))
    deliverable = s["deliverable"]
    aspect = deliverable["aspect_ratio"]
    orientation = deliverable.get(
        "orientation",
        "landscape" if aspect in ("16:9", "3:2", "2:1") else "portrait" if aspect in ("9:16", "4:5", "2:3") else "square",
    )
    anti = ", ".join(s.get("anti_list", []))

    paragraphs = [
        f"{shot_phrase} of {subject}. {action.capitalize()}. "
        f"{env['location'].capitalize()}"
        f"{_opt(signifiers, prefix=': ')}. "
        f"{time_clock}{_opt(time_era, prefix=', ')}.",

        f"Shot on {cam['format'].replace('_', ' ')} with a {cam['lens_mm']}mm lens at {cam['aperture']}, "
        f"{s['shot']['angle'].replace('_', ' ')}, {cam['depth_of_field']} depth of field.",

        "Lighting: "
        + lighting["key"]
        + _opt(lighting.get("fill"), prefix="; fill: ")
        + _opt(lighting.get("rim"), prefix="; rim: ")
        + _opt(practicals, prefix="; practicals: ")
        + f"; overall {lighting['overall_quality']}.",

        f"Color response of {color['grade']}, {color['contrast']} contrast, {color['saturation']} saturation.",

        f"Composition: subject on the {comp['subject_position'].replace('_', ' ')} "
        + _opt(comp.get("negative_space_for"), prefix="with negative space reserved for ")
        + f". Mood: {mood}.",

        f"{aspect} {orientation}, {deliverable.get('use_case', 'editorial')}.",

        f"Avoid: {anti}.",
    ]
    return "\n\n".join(p for p in paragraphs if p.strip())


def compile_midjourney(sheet: dict) -> str:
    """Midjourney likes comma-separated density and tail flags."""
    s = merge_defaults(sheet)
    bits = [
        s["subject"]["description"],
        s["action"],
        s["environment"]["location"],
        *(s["environment"].get("signifiers") or []),
        f"{s['shot']['type'].replace('_', ' ')}, {s['shot']['angle'].replace('_', ' ')}",
        f"{s['camera']['lens_mm']}mm, {s['camera']['aperture']}",
        s["lighting"]["key"],
        s["color"]["grade"],
        ", ".join(s.get("mood", [])),
    ]
    base = ", ".join(b for b in bits if b)
    flags = f" --ar {s['deliverable']['aspect_ratio'].replace(':', ':')} --stylize 200"
    if s.get("anti_list"):
        flags += " --no " + ", ".join(s["anti_list"])
    return base + flags


COMPILERS = {
    "gpt-image-2": compile_gpt_image_2,
    "openart": compile_gpt_image_2,  # OpenArt Smart Shot is GPT Image 2 underneath
    "midjourney": compile_midjourney,
    "flux": compile_gpt_image_2,
    "nano-banana": compile_gpt_image_2,
    "generic": compile_gpt_image_2,
}


def main() -> int:
    ap = argparse.ArgumentParser(description="Compile a director sheet to an image prompt.")
    ap.add_argument("sheet", help="Path to director-sheet JSON, or '-' for stdin")
    ap.add_argument("--model", default=None, help="Override target_model from the sheet")
    ap.add_argument("--size", action="store_true", help="Also print suggested API size flag")
    args = ap.parse_args()

    raw = sys.stdin.read() if args.sheet == "-" else open(args.sheet, encoding="utf-8").read()
    sheet = json.loads(raw)
    model = args.model or sheet.get("target_model", "gpt-image-2")

    compiler = COMPILERS.get(model, compile_gpt_image_2)
    prompt = compiler(sheet)

    print(prompt)
    if args.size:
        aspect = sheet.get("deliverable", {}).get("aspect_ratio", "1:1")
        print(f"\n# suggested size: {ASPECT_TO_SIZE.get(aspect, '1024x1024')}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
