# Director Sheet — Canonical Schema

This is the authoritative JSON schema for a director sheet. Read when you need to produce or parse sheets programmatically, validate user input, or plug into a pipeline.

## Schema

```json
{
  "$schema": "https://scene-director.dev/schema/v1.json",
  "version": "1.0",
  "logline": "string — one sentence capturing the whole image",
  "subject": {
    "description": "string — what/who, visually",
    "count": 1,
    "identity_note": "string|null — e.g. 'fictional character, no real person likeness'"
  },
  "action": "string — the verb/beat, present tense",
  "environment": {
    "location": "string — where",
    "signifiers": ["string"]
  },
  "time": {
    "clock": "string — '2am', 'golden hour', 'blue hour', 'noon'",
    "era": "string — 'present day', '1970s', 'near-future 2040s'"
  },
  "shot": {
    "type": "extreme_wide|wide|medium_wide|medium|medium_close|close_up|extreme_close_up|over_the_shoulder|pov",
    "angle": "eye_level|low|high|dutch|overhead|worms_eye",
    "height": "string — e.g. 'chest-height'"
  },
  "camera": {
    "format": "35mm_film|medium_format|digital_full_frame|smartphone|8mm|super8|vhs",
    "lens_mm": 35,
    "aperture": "f/1.8",
    "depth_of_field": "shallow|medium|deep"
  },
  "lighting": {
    "key": "string — source, direction, quality",
    "fill": "string|null",
    "rim": "string|null",
    "practicals": ["string"],
    "overall_quality": "soft|hard|mixed",
    "temperature_k": 3200
  },
  "composition": {
    "rule": "thirds|center|symmetry|leading_lines|negative_space|dynamic_diagonal",
    "subject_position": "left_third|center|right_third|golden_ratio",
    "negative_space_for": "string|null — 'title card top-left', else null"
  },
  "color": {
    "palette": ["string"],
    "grade": "string — 'teal and orange', 'bleach bypass', 'Kodak Portra 400'",
    "contrast": "low|medium|high",
    "saturation": "muted|natural|vibrant"
  },
  "mood": ["string"],
  "deliverable": {
    "aspect_ratio": "3:2|16:9|9:16|1:1|4:5|2:1",
    "orientation": "landscape|portrait|square",
    "use_case": "string — 'hero image for landing page', 'Instagram post', etc."
  },
  "anti_list": ["string — things to explicitly exclude"],
  "target_model": "gpt-image-2|openart|midjourney|flux|nano-banana|ideogram|veo|sora|generic",
  "notes": "string|null — freeform director commentary"
}
```

## Required vs optional

**Required** (compile fails without these): `logline`, `subject.description`, `action`, `shot.type`, `lighting.key`, `deliverable.aspect_ratio`, `target_model`.

**Strongly recommended** (compile produces worse output without them): `camera.lens_mm`, `color.grade`, `mood`, `anti_list`.

**Optional**: everything else — fill when the user signals it matters.

## Defaults (when user hasn't specified)

| Field | Default | Rationale |
|-------|---------|-----------|
| `camera.lens_mm` | 35 | Most naturalistic, fewest distortion failures |
| `camera.format` | `35mm_film` | Escapes digital plastic look |
| `shot.angle` | `eye_level` | Safest; flag when something else would be stronger |
| `lighting.overall_quality` | `soft` | Diffuse light is more forgiving than hard |
| `composition.rule` | `thirds` | Well-understood by every model |
| `color.contrast` | `medium` | Avoids HDR blowout |
| `anti_list` | `["plastic skin", "stock photo smile", "over-sharp digital look"]` | Default anti-slop floor |

Defaults should be labeled in output ("[default]" or similar) so the user knows what was filled in automatically.

## Validation rules

1. `subject.count` and number of people described must match.
2. If `time.clock` is `golden_hour` or `blue_hour`, `lighting.temperature_k` should be 2800-3400 or 4500-6500 respectively.
3. `camera.lens_mm` < 24 triggers warning about distortion on close-ups.
4. `deliverable.aspect_ratio` must be compatible with `orientation` (don't claim 9:16 is landscape).
5. `anti_list` should not contradict explicit positive requests elsewhere.
