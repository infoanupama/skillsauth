# Compiling a Director Sheet → GPT Image 2 Prompt

Read this when the target model is GPT Image 2 (also covers ChatGPT Images 2.0 / OpenArt's Smart Shot surface, which is built on GPT Image 2).

## What's different about GPT Image 2

GPT Image 2 *reasons* over the prompt before generating. This changes how you write for it:

1. **Structured prose beats keyword soup.** Old-style "photo, cinematic, 8k, ultra-detailed" prompts waste tokens. GPT Image 2 reads narrative.
2. **Named sources of light are honored.** "Warm tungsten desk lamp camera-right" becomes an actual lamp. On older models this was noise.
3. **Negative guidance is reliable.** An explicit anti-list lands. Older diffusion models ignored or inverted negatives.
4. **Typography works.** Multilingual text, infographics, UI mockups all render. If your sheet has text content, put it in quotes and specify the font feel.
5. **Director sheets compile 1:1.** The model's reasoning layer is effectively doing what this skill does — meeting it halfway with a sheet gives it less to guess.

## Compile Template

Order matters. GPT Image 2 weights earlier tokens slightly more.

```
[SHOT TYPE] of [SUBJECT with specific visual details]. [ACTION in present tense, specific beat].
[ENVIRONMENT with 2-3 signifier details]. [TIME and era].

Shot on [CAMERA/FORMAT] with a [LENS mm] lens at [APERTURE], [ANGLE], [DEPTH OF FIELD].

Lighting: [KEY description with direction], [FILL], [PRACTICALS if any], overall [QUALITY].
Color response of [FILM STOCK or grade name], [CONTRAST], [SATURATION].

Composition: subject [POSITION], [NEGATIVE SPACE usage if any].
Mood: [2-3 MOOD WORDS].

[ASPECT RATIO], [USE CASE].

Avoid: [ANTI-LIST].
```

## Worked Example

**Director sheet (excerpt):**
```json
{
  "logline": "A tired founder reads a term sheet at 2am",
  "subject": {"description": "South Asian woman, 30s, grey hoodie over pajamas, hair loosely up"},
  "action": "mid-sigh, pen held above paper, eyes fixed on document",
  "environment": {"location": "home office", "signifiers": ["IKEA desk", "plants", "window showing out-of-focus city lights"]},
  "time": {"clock": "2am", "era": "present day"},
  "shot": {"type": "medium_close", "angle": "eye_level"},
  "camera": {"format": "35mm_film", "lens_mm": 35, "aperture": "f/2.0", "depth_of_field": "shallow"},
  "lighting": {
    "key": "warm tungsten desk lamp, camera-right",
    "fill": "cool window light spilling from behind",
    "practicals": ["laptop screen glow on her face"],
    "overall_quality": "soft"
  },
  "color": {"grade": "Kodak Portra 400", "contrast": "medium", "saturation": "natural"},
  "composition": {"rule": "thirds", "subject_position": "left_third", "negative_space_for": "title card top-left"},
  "mood": ["weary", "hopeful", "private"],
  "deliverable": {"aspect_ratio": "3:2", "use_case": "hero image, pitch deck cover"},
  "anti_list": ["plastic skin", "stock-photo smile", "generic corporate office", "over-sharp digital look", "HDR blown highlights"],
  "target_model": "gpt-image-2"
}
```

**Compiles to:**
```
A medium close-up of a South Asian woman in her 30s wearing a soft grey hoodie
over pajamas, hair loosely tied up. She is mid-sigh, holding a pen above a
paper term sheet on her desk, eyes fixed on the document. Home office at 2am,
cluttered IKEA desk, a couple of houseplants, a window behind her revealing
out-of-focus city lights. Present day.

Shot on 35mm film with a 35mm lens at f/2.0, eye-level, shallow depth of field.

Lighting: warm tungsten desk lamp as the key from camera-right; cooler window
fill spilling from behind; practical laptop glow lifting her face from below;
overall soft.
Color response of Kodak Portra 400, medium contrast, natural saturation.

Composition: subject on the left third; negative space top-left reserved for a
title card. Mood: weary, hopeful, private.

3:2 landscape, hero image for a pitch deck cover slide.

Avoid: plastic skin, stock-photo smile, generic corporate office, over-sharp
digital look, HDR blown highlights.
```

## Compile Rules (for implementation)

1. Start with shot type and a dense subject description — GPT Image 2 anchors on these.
2. Convert action to present-tense verb phrase, not gerund. "she reads" > "reading".
3. Environment: max 3 signifiers. More than 3 and the model ignores the prioritization.
4. Never use "masterpiece", "ultra-realistic", "8k", "award-winning", "trending on artstation" — these are diffusion-era and add token noise without lifting quality on GPT Image 2.
5. Always close with the anti-list. Place under a literal "Avoid:" heading — the model respects the framing.
6. For multilingual text in the image, wrap exact characters in quotes: `a sign reading "東京"`.
7. For infographic/UI/slide output, add a "Text content:" section listing each visible label verbatim.

## Model-Specific Flags (when calling the API)

- `size`: map from `deliverable.aspect_ratio` (1024x1024 for 1:1, 1792x1024 for ~16:9, 1024x1792 for 9:16 — consult current API).
- `quality`: use `high` for hero assets, `standard` for iteration.
- `style`: omit unless the user wants a stylized look — the sheet controls style via color/film stock fields.

## Iteration on GPT Image 2

When the user gives feedback:

- "warmer" → bump lighting key temperature down (more tungsten), grade toward amber, recompile.
- "more dramatic" → harden key, reduce fill, lower overall saturation, shift mood language.
- "cleaner" → simplify composition, remove one environment signifier, shift grade toward modern digital.
- "less plastic" → add film stock if missing, add grain, add one imperfection (skin texture, dust in light beam).

The cheap mental model: every user comment maps to exactly one or two fields on the sheet. Find the fields, edit them, recompile. Do not touch the raw prompt.
