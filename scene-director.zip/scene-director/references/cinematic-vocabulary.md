# Cinematic Vocabulary — Quick Reference

Load this file when filling a director sheet and you need the right word. Models respond better to a specific cinematographic term than a descriptive phrase.

## Shot Types (scale)

| Term | What it captures | When to use |
|------|------------------|-------------|
| Extreme wide (EWS) | Landscape, subject small | Establish world, epic scale |
| Wide (WS) | Full body + environment | Place subject in context |
| Medium wide (MWS) | Knees up | Conversation, action |
| Medium (MS) | Waist up | Standard coverage |
| Medium close-up (MCU) | Chest up | Emotion + some context |
| Close-up (CU) | Head & shoulders | Intimate, emotional beat |
| Extreme close-up (ECU) | Eyes only, detail | Maximum intimacy, tension |
| Over-the-shoulder (OTS) | Frame a subject past another's shoulder | Dialogue, discovery |
| POV | First-person view | Immersion, identification |
| Insert | Close detail of an object | Story beats on a thing, not a face |

## Angles

- **Eye-level** — default, neutral
- **Low angle** — subject dominant, heroic
- **High angle** — subject vulnerable, small
- **Dutch (canted) tilt** — unease, instability
- **Overhead / bird's-eye** — omniscient, patterned
- **Worm's-eye** — towering, dominating
- **Profile** — iconic, classical
- **Three-quarter** — most flattering for faces

## Lens Focal Lengths (35mm equivalent)

| mm | Feel | Best for |
|----|------|----------|
| 14-20 | Extreme wide, heavy distortion | Architecture, surreal |
| 24 | Wide, environmental | Landscapes, cityscape |
| 28 | Natural wide | Street, documentary |
| 35 | Mild wide — **most versatile, good default** | Environmental portraits, narrative |
| 50 | "Nifty fifty", matches eye perspective | Everyday, naturalistic |
| 85 | Portrait lens, flattering | Portraits, shallow background |
| 135 | Long portrait, strong compression | Fashion, isolate subject |
| 200+ | Telephoto, background stacks | Sports, surveillance feel |

## Aperture → Depth of Field

- f/1.2 – f/2.0 — creamy bokeh, single-eye focus only
- f/2.8 – f/4 — subject isolated, context blurred but readable
- f/5.6 – f/8 — balanced, most professional work lives here
- f/11 – f/16 — deep focus, landscape, everything sharp

## Lighting — Source Types

- **Key light** — primary, defines form. Direction matters (camera-left, camera-right, above).
- **Fill light** — softens shadows from key. Usually opposite side, softer.
- **Rim / back light** — separates subject from background, outlines.
- **Practical** — in-scene visible source (lamp, phone screen, fireplace, neon).
- **Bounce** — light reflected off a surface (wall, card, ceiling).
- **Ambient** — general environmental light with no specific source.

## Lighting — Quality

- **Hard** — small source relative to subject → crisp shadows. Noon sun, bare bulb.
- **Soft** — large source → diffuse, flattering. Overcast, softbox, window light.
- **Diffused / wrapped** — light bends around subject. Window sheer, overcast.
- **Directional** — clearly from one side. Window, lamp.
- **Ambient** — omnidirectional, low contrast.

## Lighting — Named Setups

- **Rembrandt** — triangle of light on cheek opposite the key. Classic portrait.
- **Split** — half face lit, half shadow. Dramatic, noir.
- **Loop** — small shadow of nose loops toward cheek. Standard flattering.
- **Butterfly / paramount** — key from directly above, shadow under nose. Glamour.
- **Short / broad** — which side of face (away from camera / toward camera) is lit.
- **Low-key** — predominant shadow, small lit area. Noir, thriller.
- **High-key** — predominant highlight, minimal shadow. Comedy, fashion, commercial.
- **Chiaroscuro** — extreme light/dark contrast. Painterly, Caravaggio.

## Color Temperature (Kelvin)

| K | Feel | Example |
|---|------|---------|
| 1700 | Candlelight | Dinner, intimate |
| 2400 | Incandescent bulb | Home interior, warm |
| 3200 | Tungsten film standard | Cinema indoor |
| 4000 | Fluorescent | Office, clinical |
| 5600 | Daylight film standard | Outdoor noon |
| 6500 | Overcast sky | Cool, pensive |
| 10000 | Deep shade, blue hour | Cold, melancholy |

## Film Stocks / Color Responses

- **Kodak Portra 400** — warm skin, forgiving highlights, slight grain. Weddings, portraiture.
- **Kodak Gold 200** — saturated, golden, nostalgic, 90s family feel.
- **Kodak Ektar 100** — vivid color, landscape, magazine feel.
- **Fuji Pro 400H** — pastels, muted greens, airy. Fashion.
- **Fuji Velvia** — extreme saturation, nature photography.
- **Cinestill 800T** — tungsten-balanced, halation bloom on highlights. Night scenes, neon.
- **Ilford HP5 / Tri-X** — classic black and white, grain, flexible.
- **Polaroid SX-70** — milky whites, soft focus, dreamy.
- **VHS / Super-8** — lo-fi, motion blur, scan lines. Nostalgia.
- **Digital full-frame, clean** — modern editorial, commercial.

## Color Grades

- **Teal & orange** — blockbuster standard
- **Bleach bypass** — desaturated, high contrast, gritty (Saving Private Ryan)
- **Warm amber** — golden hour, nostalgia
- **Cool cyan / blue hour** — night, melancholy
- **Pastel wash** — Wes Anderson, youthful
- **Monochrome** — black and white, timeless
- **Noir** — deep blacks, harsh contrast
- **Neon pop** — cyberpunk, night city

## Composition

- **Rule of thirds** — subject on 1/3 line
- **Golden ratio / spiral** — organic, classical
- **Centered / symmetry** — Kubrick, formal
- **Leading lines** — eye drawn by diagonals
- **Frame within frame** — doorway, window around subject
- **Negative space** — large empty area, typography slot
- **Headroom** — space above head; reduce for claustrophobia
- **Lead room / nose room** — space in direction subject looks

## Mood Words That Actually Work

Specific beats beat vague adjectives.

- Melancholy, pensive, yearning → beats "sad"
- Conspiratorial, surreptitious, charged → beats "tense"
- Reverent, hushed, liminal → beats "quiet"
- Exuberant, unguarded, kinetic → beats "happy"
- Weary, frayed, held-together → beats "tired"

## Aspect Ratios (common)

- **1:1** — Instagram post, album cover
- **4:5** — Instagram portrait, book cover
- **3:2** — DSLR standard, print
- **16:9** — widescreen, landing pages
- **9:16** — reels, stories, vertical video
- **2:1** — cinematic, modern film
- **2.39:1** — anamorphic, epic cinema
- **4:3** — classic TV, Super-8, nostalgic
