# Installing scene-director

This skill follows the official Anthropic Agent Skills spec (YAML frontmatter with `name` + `description`, markdown body, optional `references/`, `assets/`, `scripts/` subfolders). The same folder works across every tool — only the install mechanism differs.

## File formats

You get two downloads:

- `scene-director.zip` — universal ZIP of the folder. Unpack anywhere.
- `scene-director.skill` — the same ZIP, renamed. Some tools (notably Cowork) recognize the `.skill` extension for one-click install.

Either works everywhere. They have identical contents.

---

## Claude Code (CLI)

Claude Code reads skills from `~/.claude/skills/` (personal) or `.claude/skills/` (per-project).

```bash
# Personal install, available in every session
unzip scene-director.zip -d ~/.claude/skills/

# Or per-project install
cd your-project
mkdir -p .claude/skills
unzip scene-director.zip -d .claude/skills/
```

Verify: start Claude Code in the folder, type `/skills` — you should see `scene-director` in the list. Then ask for a cinematic image — the skill auto-triggers from the description.

## Cowork (desktop app)

Two options.

1. **One-click**: drop `scene-director.skill` into a chat in Cowork → a "Save skill" button appears → click it. Done.
2. **Folder**: unpack `scene-director.zip` and place the `scene-director/` folder in your Cowork skills directory (same path as Claude Code: `~/.claude/skills/`).

Verify: ask Cowork to "make a cinematic hero image of a founder reading a term sheet at 2am" — you should see the skill load and produce a director sheet before any image.

## Claude API / Agent SDK

Point the SDK at the skill folder — Anthropic's SDK has first-class support for skills as of v0.x.

```python
from anthropic import Anthropic
client = Anthropic()
# Pass the skill directory when creating your agent — the SDK auto-loads SKILL.md
agent = client.agents.create(
    model="claude-opus-4-6",
    skills=["./scene-director"],  # path to unpacked folder
)
```

See the [Agent SDK skills docs](https://platform.claude.com/docs/en/agent-sdk/skills) for the current API.

## Cursor

Cursor doesn't natively understand `SKILL.md` yet (it uses `.cursorrules` or `AGENTS.md`). Two options:

1. **Copy SKILL.md contents into `.cursorrules`** at the root of your project. Cursor will inject it as system instructions. The references in `references/` won't auto-load — paste the ones you need inline, or tell Cursor to read them via file path.
2. **Use Claude as an external tool** — Cursor's "Ask Claude" / agent features can call Claude with skills attached.

When Cursor adds native skill support (the format is deliberately open), this folder will drop in unchanged.

## OpenAI Codex CLI / Codex

Codex uses `AGENTS.md` at the project root. Copy the markdown body of `SKILL.md` (everything after the `---` frontmatter) into `AGENTS.md` under a `## scene-director` heading. The skill's reasoning still works because the instructions are tool-agnostic — only the compile step (`scripts/render_prompt.py`) is a Python file Codex can run directly.

```bash
cat scene-director/SKILL.md | sed '1,/^---$/d' | sed '1,/^---$/d' >> AGENTS.md
```

Then `cd` into the folder and run `python scripts/render_prompt.py assets/example-sheet.json` to verify the compile step works.

## OpenArt (if/when they ship skill support)

This skill is built to drop into OpenArt's Smart Shot pipeline as the reasoning layer. See `PITCH_TO_OPENART.md` — tl;dr, send them the `.skill` bundle and the pitch; they can wire `render_prompt.py` into their prompt compile step in an afternoon.

---

## Verifying the skill works

Regardless of tool, one offline test proves the compiler works:

```bash
cd scene-director
python3 scripts/render_prompt.py assets/example-sheet.json
```

Expected output: a fully compiled GPT Image 2 prompt with specific lens, named light sources, film stock, and anti-list. If you see that, the skill is installed and functional — the reasoning part is handled by whichever Claude model is running.

## Editing the skill

The only file you'd normally edit is `SKILL.md` itself (to tune trigger conditions or workflow) or `references/gpt-image-2-prompting.md` (to add model-specific compile rules for a new target). Everything else is reference material the model reads on demand.

After editing, re-run the tests in `evals/evals.json` — either by hand or with Anthropic's [skill-creator harness](https://github.com/anthropics/skills/tree/main/skills/skill-creator).

## Requirements

- Python 3.8+ for the compile script (standard library only — no pip install needed)
- Any Claude model (Sonnet, Opus, Haiku) that supports Agent Skills
- For image output: an account on GPT Image 2 / OpenArt / Midjourney / etc.

No external dependencies, no API keys needed for the skill itself — only for the image model you eventually send the compiled prompt to.
