# How to Test Scene Director

Three ways to evaluate this skill, listed easiest → most rigorous.

## Option 1 — Drop in and vibe test (5 minutes)

The fastest sanity check. Works anywhere you can install a skill.

1. Install the skill:
   - In Claude Code / Cowork: drop the `scene-director/` folder into `~/.claude/skills/` (or use the `.skill` installer if presented).
   - In OpenArt (once integrated): the skill's `SKILL.md` is the system instruction, `scripts/render_prompt.py` is the compile step in the Smart Shot pipeline.

2. Run each prompt from `evals/evals.json` and inspect the output:
   - Does Claude produce a director sheet before the prompt?
   - Does the prompt include specific lens, named light sources, film stock, anti-list?
   - On the iteration test (#3), does it edit the sheet or hand-edit the prompt?

3. Eyeball the generated images. Compare "Scene Director on" vs "skill off" side by side.

## Option 2 — Structured A/B (30 minutes)

Uses Anthropic's own skill-creator harness — this is how they validate skills internally.

```bash
cd scene-director/
# Spawn both arms (with skill, without) for each eval
python -m scripts.aggregate_benchmark ./workspace/iteration-1 --skill-name scene-director
python <skill-creator-path>/eval-viewer/generate_review.py \
  ./workspace/iteration-1 --skill-name scene-director --static ./review.html
```

Then open `review.html` and click through. You'll see the baseline (no skill) and the with-skill output side by side, plus a benchmark tab with pass rate and token spend per configuration. The skill-creator skill on your system walks this flow end-to-end.

Measure three things:
- **Fidelity to intent** (human judgment — which image matched the user's mental picture?)
- **Retries saved** (count how many generations before user said "yes, that's it")
- **Token / latency cost** (should be small — sheet compile is cheap)

## Option 3 — Production A/B in OpenArt (if you ship it)

The real test. Gate Scene Director behind a 5% traffic flag in OpenArt's prompt pipeline and measure:

| Metric | Hypothesis |
|--------|------------|
| Regenerations per session | ↓ 20-40% |
| Time to first "accept" | ↓ 15-30% |
| User-initiated prompt edits | ↓ (they edit sheet fields instead) |
| Share/export rate per generation | ↑ (higher quality output per gen) |
| Cost per accepted image | ↓ because fewer throwaway generations |

At 8M MAU, even a 15% drop in retries pays the compute bill for the reasoning layer.

## What "passing" looks like for each test

**Test 1 (underspecified prompt):**
- Without skill: vague, stock-looking image, user retries 3-5 times.
- With skill: one director sheet, one compiled prompt, generally 1-2 retries max.

**Test 2 (commercial hero image):**
- Without skill: generic corporate imagery.
- With skill: aspect ratio matches landing-page hero, negative space reserved for headline, anti-list excludes "corporate stock".

**Test 3 (iteration):**
- Without skill: model tacks "warm, 35mm, imperfect" onto the previous prompt; quality roulette.
- With skill: explicitly names which sheet fields changed (lighting.temperature_k, color.grade, anti_list), recompiles, delivers a predictable shift.

## Quick manual test (no harness needed)

If you just want to see it work right now:

```bash
cd scene-director
python3 scripts/render_prompt.py assets/example-sheet.json
```

The output is a fully compiled GPT Image 2 prompt. Paste that into any image model. Then modify one field in the example JSON (e.g., change `color.grade` to `"bleach bypass"` and rerun) — watch a single intent-level edit change the entire prompt consistently. That's the core value prop in one minute.
